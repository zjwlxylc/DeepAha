# rc1 → rc2 来源资产对齐差异包

完整系统请优先使用 DeepAha_Rebuild_3.0.0-rc2.zip。

本包files内为相对rc1新增或修改的文件；PATCH_MANIFEST.json给出原文件SHA-256与新SHA-256。不要将它直接覆盖不同版本或有用户改动的工作树。由Codex先比对所有base_sha256，任何不符先合并检查，不擅自覆盖。

不包含或改写数据库、WMA凭据、系统环境和公网配置。代码采用后，停止API/Worker，按docs/source-import/04_USER_AND_UPGRADE.md备份并升级数据表，再运行测试。只替换前端不能完成本功能。

没有删除旧历史代码或修改已经应用的Alembic迁移。
