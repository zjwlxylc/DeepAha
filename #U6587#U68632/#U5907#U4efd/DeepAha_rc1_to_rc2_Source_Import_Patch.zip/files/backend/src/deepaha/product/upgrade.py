"""Explicit additive rc1→rc2 upgrade. SQLite is backed up before any DDL.

PostgreSQL requires an operator-managed pg_dump and the existing `init` command;
this helper deliberately does not pretend to create a portable PostgreSQL backup.
"""
from pathlib import Path
from sqlalchemy import inspect
from .models import Meta
from .scout_models import SCOUT_TABLE_NAMES
from .backup import create_backup,verify_backup
from .errors import Problem


def upgrade_source_intake(product, backup_path):
    tables=set(inspect(product.db.engine).get_table_names())
    if 'product_meta' not in tables:
        raise Problem('不是重建版数据目录；新安装请运行setup，原系统请按迁移文档处理',409,'NOT_REBUILD_DATABASE')
    with product.db.tx(False) as s:
        version=s.get(Meta,'schema_version');scout=s.get(Meta,'scout_schema_version')
        if not version or version.value!='1' or (scout and scout.value!='1'):
            raise Problem('数据库版本不兼容；未做变更',409,'UPGRADE_VERSION')
        if scout and SCOUT_TABLE_NAMES.issubset(tables):
            return {'already_current':True,'source_intake_version':'1','data_modified':False}
    if not product.database_url.startswith('sqlite:///'):
        raise Problem('PostgreSQL请先停服务并用pg_dump备份，再执行init；本命令不代替数据库备份',409,'POSTGRES_BACKUP_REQUIRED')
    backup=create_backup(product.database_url,product.object_root,Path(backup_path))
    verify_backup(backup['backup'])
    product.initialize()
    if not SCOUT_TABLE_NAMES.issubset(set(inspect(product.db.engine).get_table_names())):
        raise Problem('新增表未全部创建；备份已保留',503,'UPGRADE_INCOMPLETE')
    return {'source_intake_version':'1','backup':backup['backup'],'backup_verified':True,
            'already_current':False,'existing_rows_preserved':True,'sources_approved':0,'tasks_created':0}
