import {spawnSync} from 'node:child_process';
import {readdirSync,readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../public/product/',import.meta.url));
for(const name of readdirSync(root).filter(x=>x.endsWith('.js'))){const r=spawnSync(process.execPath,['--check',root+name],{stdio:'inherit'});if(r.status)process.exit(r.status);}
for(const name of ['app.js','core.js','user.js','workbench.js','scout.js']){const s=readFileSync(root+name,'utf8');if(/localStorage|sessionStorage|fixtures\.js/.test(s))throw new Error('Business fixture/persistence code in '+name);}
console.log('Product JavaScript syntax and no-fixture checks passed');
