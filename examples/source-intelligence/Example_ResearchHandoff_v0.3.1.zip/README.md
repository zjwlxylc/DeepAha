# 研究资产交接包

本包由本地审核工作台生成，**尚未导入DeepAha**。

先阅读 ResearchHandoff.json 的 readiness 与 counts，再核查 Decisions.json。Audit.json 保留所有候选版本、证据、Brief和关系。
originals 是原始输入，不得用投影替代。Manifest.json 校验各文件SHA-256。反馈文件自报未认证，不代表来源已批准。
主系统需要接收 deepaha.research-handoff.v1 的专用候选暂存适配器，不能直接调用旧 v1执行接口。
